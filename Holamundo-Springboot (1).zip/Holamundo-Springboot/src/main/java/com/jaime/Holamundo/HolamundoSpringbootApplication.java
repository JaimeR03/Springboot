package com.jaime.Holamundo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolamundoSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolamundoSpringbootApplication.class, args);
	}

}
